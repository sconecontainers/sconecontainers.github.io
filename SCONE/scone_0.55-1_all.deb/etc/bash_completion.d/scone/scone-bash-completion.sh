#!/bin/bash
#
# bash completion for scone 
#
# todo: needs some more work to be more context sensitive
#
# /etc/bash_completion.d/scone
#
# (C) Christof Fetzer, 2017

# terminate

path="/opt/scone/bin/"

# todo: options after which we terminate to provide completions
terminating="--help"

# todo: options that are checked for more options
index_option="--type"

# scone objects (arg 1)
objects="doctor host monitor scope sentry volume --help --version"  # = cmd_list

# commands per object (arg 2 - depends on arg1)
host_commands="install uninstall acquire release list endpoints login check reboot --help"
monitor_commands="check install uninstall tunnel --help"

# scone host related definitions

# options per object and command (arg x - depends on arg1 and arg2)
  host_install_options="--help --verbose --debug --name --join --as-manager --force"
host_uninstall_options="--help --verbose --debug --name --force"
  host_acquire_options="--help --verbose --debug --name --endpoint --join --as-manager --force"
  host_release_options="--help --verbose --debug --name --fast"
host_endpoints_options="--help --verbose --debug"
     host_list_options="--help --verbose --debug --managers"
    host_login_options="--help --verbose --debug --type --name --import --export"
   host_reboot_options="--help --verbose --debug --name --force"
    host_check_options="--help --verbose --debug --name"

# options per object and command (arg x - depends on arg1 and arg2 and prev)

# host install

host_install_help_list=":"
host_install_name_list=":${path}scone host list"
host_install_join_list=":${path}scone host list --managers"

# host uninstall

host_uninstall_help_list=":"
host_uninstall_name_list=":${path}scone host list"

# host acquire

host_acquire_help_list=":"
host_acquire_endpoint_list=":${path}scone host endpoints -s"
host_acquire_name_list=":"  ## new name
host_acquire_join_list=":${path}scone host list --managers"  ## should consider endpoint specified...

# host release

host_release_help_list=":"
host_release_name_list=":${path}scone host list"

# host endpoints

host_endpoints_help_list=":"

# host list

host_list_help_list=":"



# host check

host_check_help_list=":"
host_check_name_list=":${path}scone host list"

# host login

host_login_type_list="kvm maas openstack ironic"
host_login_name_list=":" # term
host_login_help_list=":"
host_login_token_list=":"
host_login_user_list=":"
host_login_host_list=":${path}scone host list"
host_login_keyfile_list=":"
host_login_import_list=":"
host_login_export_list=":"


host_login_kvm_options="--host"
host_login_openstack_options="--url --token"
host_login_maas_options="--user --url --keyfile"
host_login_ironic_options="--url --token"

# todo: use nospace..
host_login_url_list="https://"


# host reboot

host_reboot_help_list=":"
host_reboot_name_list=":"  # scone host list


host_acquire_name_arg="$(scone host endpoints -s)"

function remove_duplicates {
    local args="$1"
    local cur="${COMP_WORDS[COMP_CWORD]}"

    reply=""
    for arg in $args ; do
        copy=true
        for word in ${COMP_WORDS[@]} ; do
            if [[ "$arg" == "$word" ]] ; then
                copy=false
            fi
        done
        if [[ $copy == true ]] ; then
            reply="$reply $arg"
        fi
    done
    COMPREPLY=( $( compgen -W "$reply" -- $cur) )
}

function _scone {
    local cur prev

    COMPREPLY=()
    local cur="${COMP_WORDS[COMP_CWORD]}"
    prev=${COMP_WORDS[COMP_CWORD-1]}
    object=${COMP_WORDS[1]}

    # first check for special cases here ...
        # todo: remove some of the annoyances of the generic approach here...

    # second, try generic approach 

    trobject=`echo $object | tr -cd [:alnum:]` 

    if [[ $COMP_CWORD == 1 ]] ; then
        COMPREPLY=( $( compgen  -W "$objects" -- $cur) )
    elif [[ $COMP_CWORD == 2 ]] ; then
        var=${trobject}_commands
        if [[  "${!var}" != "" ]] ; then
            COMPREPLY=( $( compgen -W "${!var}" -- $cur) )
        else
            COMPREPLY=(  )
        fi
    else
        command=`echo ${COMP_WORDS[2]} | tr -cd [:alnum:]`

        if [[ "$prev" =~ ^-- ]] ; then
            trprev=`echo $prev | tr -cd [:alnum:]`
            var=${trobject}_${command}_${trprev}_list
            var=${!var}
            if [[  "$var" != "" ]] ; then
                if [[  "$var"  =~ ^: ]] ; then  # shell command or empty completion?
                    cmd=${var:1}
                    if [[ "$var" != "" ]] ; then
                        var=`$cmd`
                        COMPREPLY=( $( compgen -W "$var" -- $cur) )
                    else
                        COMPREPLY=()
                    fi
                else # else use static list
                    COMPREPLY=( $( compgen -W "${!var}" -- $cur) )
                fi
                return 0
            fi
        fi

# check if we have seen an "indexed option":

        for i in `seq 1 $COMP_CWORD` ; do
            if [[ "${COMP_WORDS[$i]}" == "$index_option" ]] ; then
                let j=i+1
                var=${trobject}_${command}_${COMP_WORDS[$j]}_options
                if [[  "${!var}" != "" ]] ; then
                    COMPREPLY=( $( compgen -W "${!var}" -- $cur) )
                    return 0
                fi
            fi
        done

        var=${trobject}_${command}_options
        if [[  "${!var}" != "" ]] ; then
            remove_duplicates "${!var}"
            # COMPREPLY=( $( compgen -W "${!var}" -- $cur) )
        else
            COMPREPLY=(  )
        fi        
    fi

}

complete -F _scone scone
